<?php
/**
 * The template to display the download's features on the single page
 *
 * @package WordPress
 * @subpackage ThemeREX Addons
 * @since v1.6.29
 */

$trx_addons_args = get_query_var('trx_addons_args_sc_edd_details');

$trx_addons_meta = get_post_meta(get_the_ID(), 'trx_addons_options', true);

if (!empty($trx_addons_args['type'])) {
	?><div<?php
			if (!empty($trx_addons_args['id'])) echo ' id="'.esc_attr($trx_addons_args['id']).'"';
			if (!empty($trx_addons_args['class'])) echo ' class="'.esc_attr($trx_addons_args['class']).'"';
			if (!empty($trx_addons_args['css'])) echo ' style="'.esc_attr($trx_addons_args['css']).'"';
	?>><?php
}

// Details
?><section class="downloads_page_section downloads_page_details"><?php
	// Title
	?><h4 class="downloads_page_section_title"><?php esc_html_e('Details', 'basekit'); ?></h4><?php
	// Data
	?><div class="downloads_page_features_list"><?php
		// Date price
		if (!empty($trx_addons_args['type'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Price:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data downloads_page_price"><?php edd_price(get_the_ID()); ?></span>
			</span><?php
		}
		// Date created
		if (!empty($trx_addons_meta['date_created'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Created:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php echo date(get_option('date_format'), strtotime($trx_addons_meta['date_created'])); ?></span>
			</span><?php
		}
		// Date updated
		if (!empty($trx_addons_meta['date_updated'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Updated:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php echo date(get_option('date_format'), strtotime($trx_addons_meta['date_updated'])); ?></span>
			</span><?php
		}
		// Version
		if (!empty($trx_addons_meta['version'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Version:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php echo esc_html($trx_addons_meta['version']); ?></span>
			</span><?php
		}
		// Widgets
		if (!empty($trx_addons_meta['widgets'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Widgets:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php
					trx_addons_show_layout(trx_addons_get_option_title(TRX_ADDONS_EDD_PT, 'widgets', $trx_addons_meta['widgets']));
				?></span>
			</span><?php
		}
		// Shortcodes
		if (!empty($trx_addons_meta['shortcodes'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Shortcodes:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php
					trx_addons_show_layout(trx_addons_get_option_title(TRX_ADDONS_EDD_PT, 'shortcodes', $trx_addons_meta['shortcodes']));
				?></span>
			</span><?php
		}
		// Columns
		if (!empty($trx_addons_meta['columns'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Columns:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php
					trx_addons_show_layout(trx_addons_get_option_title(TRX_ADDONS_EDD_PT, 'columns', $trx_addons_meta['columns']));
				?></span>
			</span><?php
		}
		// Documentation
		if (!empty($trx_addons_meta['documentation'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Documentation:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php
					trx_addons_show_layout(trx_addons_get_option_title(TRX_ADDONS_EDD_PT, 'documentation', $trx_addons_meta['documentation']));
				?></span>
			</span><?php
		}
		// Support
		if (!empty($trx_addons_meta['support'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Support:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php
					trx_addons_show_layout(trx_addons_get_option_title(TRX_ADDONS_EDD_PT, 'support', $trx_addons_meta['support']));
				?></span>
			</span><?php
		}
		// Retina
		if (!empty($trx_addons_meta['retina'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('High resolution:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php echo (int) $trx_addons_meta['retina'] > 0 ? esc_html__('Yes', 'trx_addons') : esc_html__('No', 'trx_addons'); ?></span>
			</span><?php
		}
		// Responsive
		if (!empty($trx_addons_meta['responsive'])) {
			?><span class="downloads_page_section_item"><?php
				?><span class="downloads_page_label"><?php esc_html_e('Responsive:', 'trx_addons'); ?></span><?php
				?><span class="downloads_page_data"><?php echo (int) $trx_addons_meta['responsive'] > 0 ? esc_html__('Yes', 'trx_addons') : esc_html__('No', 'trx_addons'); ?></span>
			</span><?php
		}
		// Additional details
		if (!empty($trx_addons_meta['details']) && is_array($trx_addons_meta['details'])) {
			foreach ($trx_addons_meta['details'] as $detail) {
				if (!empty($detail['title'])) {
					?><span class="downloads_page_section_item"><?php
						?><span class="downloads_page_label"><?php
							trx_addons_show_layout(trx_addons_prepare_macros($detail['title'])); 
						?>:</span><?php
						?><span class="downloads_page_data"><?php 
							trx_addons_show_layout(trx_addons_prepare_macros($detail['value'])); 
						?></span>
					</span><?php
				}
			}
		}
	?></div>
</section><?php

// Compatibilities
?><section class="downloads_page_section downloads_page_compatibilities"><?php
	// Title
	?><h4 class="downloads_page_section_title"><?php esc_html_e('Compatible with', 'basekit'); ?></h4><?php
	// Data
	?><div class="downloads_page_features_list">
		<?php basekit_show_layout(basekit_get_post_terms('', get_the_ID(), BASEKIT_EDD_TAXONOMY_COMPATIBILITY)); ?>
	</div>
</section><?php

// Browsers support
?><section class="downloads_page_section downloads_page_browsers"><?php
	// Title
	?><h4 class="downloads_page_section_title"><?php esc_html_e('Browsers support', 'basekit'); ?></h4><?php
	// Data
	?><div class="downloads_page_features_list">
		<?php basekit_show_layout(basekit_get_post_terms('', get_the_ID(), BASEKIT_EDD_TAXONOMY_BROWSERS)); ?>
	</div>
</section><?php

// Package items
?><section class="downloads_page_section downloads_page_browsers"><?php
	// Title
	?><h4 class="downloads_page_section_title"><?php esc_html_e('Package parts', 'basekit'); ?></h4><?php
	// Data
	?><div class="downloads_page_features_list">
		<?php basekit_show_layout(basekit_get_post_terms('', get_the_ID(), BASEKIT_EDD_TAXONOMY_PACKAGE)); ?>
	</div>
</section><?php

// Plugins included
?><section class="downloads_page_section downloads_page_browsers"><?php
	// Title
	?><h4 class="downloads_page_section_title"><?php esc_html_e('Plugins included', 'basekit'); ?></h4><?php
	// Data
	?><div class="downloads_page_features_list">
		<?php basekit_show_layout(basekit_get_post_terms('', get_the_ID(), BASEKIT_EDD_TAXONOMY_PLUGINS)); ?>
	</div>
</section><?php

if (!empty($trx_addons_args['type'])) {
	?></div><?php
}
?>